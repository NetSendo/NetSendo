<?php
/**
 * NetSendo API Communication Class
 *
 * @package NetSendo_WordPress
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class NetSendo_WP_API
 * Handles all communication with NetSendo API
 */
class NetSendo_WP_API {

    /**
     * @var string API base URL
     */
    private $api_url;

    /**
     * @var string API Key
     */
    private $api_key;

    /**
     * Constructor
     *
     * @param string|null $api_url Optional API URL (uses saved settings if null)
     * @param string|null $api_key Optional API Key (uses saved settings if null)
     */
    public function __construct(?string $api_url = null, ?string $api_key = null) {
        if ($api_url !== null && $api_key !== null) {
            // Use provided values (for testing before saving)
            $this->api_url = rtrim($api_url, '/');
            $this->api_key = $api_key;
        } else {
            // Load from saved settings
            $settings = NetSendo_WP_Admin_Settings::get_settings();
            $this->api_url = rtrim($settings['api_url'] ?? '', '/');
            $this->api_key = $settings['api_key'] ?? '';
        }
    }

    /**
     * Check if API is configured
     *
     * @return bool
     */
    public function is_configured() {
        return !empty($this->api_url) && !empty($this->api_key);
    }

    /**
     * Add subscriber to a list
     *
     * @param int $list_id List ID
     * @param string $email Subscriber email
     * @param string $name Subscriber name
     * @param array $custom_fields Additional custom fields
     * @return bool|array Success or error
     */
    public function add_subscriber($list_id, $email, $name = '', $custom_fields = []) {
        if (!$this->is_configured()) {
            $this->log('API not configured');
            return false;
        }

        $endpoint = $this->api_url . '/api/v1/subscribers';

        // Parse name into first and last name
        $name_parts = explode(' ', $name, 2);
        $first_name = $name_parts[0] ?? '';
        $last_name = $name_parts[1] ?? '';

        $body = [
            'email' => $email,
            'first_name' => $first_name,
            'last_name' => $last_name,
            // The NetSendo API names the list contact_list_id (list_id was rejected with 422)
            'contact_list_id' => (int) $list_id,
            'status' => 'active',
            'custom_fields' => $custom_fields,
        ];

        $response = wp_remote_post($endpoint, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            'body' => json_encode($body),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            $this->log('API Error: ' . $response->get_error_message());
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code >= 200 && $code < 300) {
            $this->log('Subscriber added successfully: ' . $email . ' to list ' . $list_id);
            return $body;
        }

        $this->log('API Error: ' . ($body['message'] ?? 'Unknown error') . ' (Code: ' . $code . ')');
        return false;
    }

    /**
     * Get available lists from NetSendo
     *
     * @return array|false
     */
    public function get_lists() {
        if (!$this->is_configured()) {
            return false;
        }

        $endpoint = $this->api_url . '/api/v1/lists';

        $response = wp_remote_get($endpoint, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept' => 'application/json',
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            $this->log('API Error getting lists: ' . $response->get_error_message());
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code >= 200 && $code < 300) {
            return $body['data'] ?? $body;
        }

        $this->log('API Error getting lists: ' . ($body['message'] ?? 'Unknown error'));
        return false;
    }

    /**
     * Get custom fields from NetSendo
     *
     * @return array|false
     */
    public function get_custom_fields() {
        if (!$this->is_configured()) {
            return false;
        }

        $endpoint = $this->api_url . '/api/v1/custom-fields';

        $response = wp_remote_get($endpoint, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept' => 'application/json',
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            $this->log('API Error getting custom fields: ' . $response->get_error_message());
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code >= 200 && $code < 300) {
            return $body['data'] ?? $body;
        }

        $this->log('API Error getting custom fields: ' . ($body['message'] ?? 'Unknown error'));
        return false;
    }

    /**
     * Check if email is subscribed to a list
     *
     * @param string $email
     * @param int|null $list_id
     * @return bool
     */
    public function is_subscribed($email, $list_id = null) {
        if (!$this->is_configured()) {
            return false;
        }

        $endpoint = $this->api_url . '/api/v1/subscribers/by-email/' . urlencode($email);

        $response = wp_remote_get($endpoint, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept' => 'application/json',
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200 && !empty($body['data'])) {
            // The API returns one subscriber object, with the IDs of its lists in contact_list_ids
            $subscriber = $body['data'];
            if (($subscriber['status'] ?? '') !== 'active') {
                return false;
            }
            if ($list_id) {
                $list_ids = array_map('intval', (array) ($subscriber['contact_list_ids'] ?? []));
                return in_array((int) $list_id, $list_ids, true);
            }
            return true;
        }

        return false;
    }

    /**
     * Test API connection
     *
     * @return array
     */
    public function test_connection() {
        if (!$this->is_configured()) {
            return [
                'success' => false,
                'message' => __('API is not configured. Please enter API URL and API Key.', 'netsendo-wordpress'),
            ];
        }

        // Use account info endpoint to get user_id
        $endpoint = $this->api_url . '/api/v1/account';

        $response = wp_remote_get($endpoint, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept' => 'application/json',
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200) {
            // Extract and save user_id for Pixel tracking
            $user_id = $body['data']['id'] ?? $body['id'] ?? null;
            if ($user_id) {
                $this->save_user_id($user_id);
            }

            return [
                'success' => true,
                'message' => __('Connection successful! NetSendo API is working.', 'netsendo-wordpress'),
                'user_id' => $user_id,
            ];
        } elseif ($code === 401) {
            return [
                'success' => false,
                'message' => __('Authentication failed. Please check your API Key.', 'netsendo-wordpress'),
            ];
        } else {
            return [
                'success' => false,
                'message' => sprintf(__('API returned error code: %d', 'netsendo-wordpress'), $code),
            ];
        }
    }

    /**
     * Save user_id and API settings for Pixel tracking
     * This is called after successful connection test to persist settings
     *
     * @param int $user_id
     */
    private function save_user_id($user_id) {
        $settings = get_option(NetSendo_WP_Admin_Settings::OPTION_NAME, []);
        $settings['user_id'] = (int) $user_id;

        // Also save api_url and api_key if they differ from saved values
        // This auto-saves settings after successful test
        if (!empty($this->api_url) && $this->api_url !== ($settings['api_url'] ?? '')) {
            $settings['api_url'] = $this->api_url;
        }
        if (!empty($this->api_key) && $this->api_key !== ($settings['api_key'] ?? '')) {
            $settings['api_key'] = $this->api_key;
        }

        update_option(NetSendo_WP_Admin_Settings::OPTION_NAME, $settings);

        // Log for debugging
        $this->log('Saved user_id: ' . $user_id . ' and API settings');
    }

    /**
     * Log message for debugging
     *
     * @param string $message
     */
    private function log($message) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[NetSendo WordPress] ' . $message);
        }
    }
}
